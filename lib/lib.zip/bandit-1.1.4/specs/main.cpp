#include <specs/specs.h>

int main(int argc, char* argv[])
{
  return bandit::run(argc, argv);
}
